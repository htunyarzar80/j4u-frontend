import { Route, Routes } from "react-router-dom";
import Home from "./components/pages/Home";
import Register from "./components/pages/Register";
import MainNav from "./components/layout/MainNav";
import Footer from "./components/layout/Footer";

import ContactPage from "./components/pages/ContactPage";
import Companies from "./components/pages/companies/Companies";
import JobDetails from "./components/pages/jobs/JobDetails";
import Jobs from "./components/pages/jobs/Jobs";
import Profile from "./components/pages/Profile";
import CompanyDetails from "./components/pages/companies/CompanyDetails";
import Application from "./components/pages/jobs/Application";
import ProfilePage from "./components/pages/ProfilePage";
import SideNav from "./components/admin/components/Layout/SideNav";
import JobForm from "./components/admin/components/form/JobForm";
import JobTable from "./components/admin/components/Table/JobTable";


function App() {
  return (
    <div>
     
      {/* <MainNav/> */}
      <SideNav/>
        <Routes>
          <Route path="/home" element={<Home />} />
          <Route path="/register" element={<Register />} />
          <Route path="/companies" element={<Companies />} />
          <Route path="/jobs" element={<Jobs />} />
          <Route path="/jobDetails" element={<JobDetails />} />
          <Route path="/contactPage" element={<ContactPage />} />
          <Route path="/profile" element={<Profile/>} />
          <Route path="/comDetails" element={<CompanyDetails/>} />
          <Route path="/apply" element={<Application/>} />
          <Route path="/info" element={<ProfilePage/>} />

          <Route path="/jobform" element={<JobForm/>} />
          <Route path="/jobtable" element={<JobTable/>} />

        </Routes>
     {/* <Footer/> */}
    </div>
  );
}

export default App;
