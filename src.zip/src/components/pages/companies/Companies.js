import { Link } from "react-router-dom";
import "./Companies.css";
import CompanyList from "./CompanyList";

function Companies() {
  return (
    <>
      <div class="container py-5 bg-dark company-header mb-2">
        <div class="container my-5 pt-5 pb-5">
          <h1 class="display-3 text-white mb-3 animated slideInDown">
            Companies Lists
          </h1>
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb text-uppercase">
              <li class="breadcrumb-item text-white">
                <Link href="#">Home</Link>
              </li>
              <li class="breadcrumb-item text-white">
                <Link href="#">Pages</Link>
              </li>
              <li class="breadcrumb-item text-white active" aria-current="page">
                Companies Lists
              </li>
            </ol>
          </nav>
        </div>
      </div>

      <div
        className="container w-75 bg-primary mb-2  fadeIn search"
        data-delay="0.1s"
        style={{ padding: "30px" }}
      >
        <div className="container ">
          <div className="row g-2">
            <div className="col-md-12">
              <div className="row g-2">
                <div className="col-md-5">
                  <input
                    type="text"
                    className="form-control border-0 h-100"
                    placeholder="Company Name"
                  />
                </div>

                <div className="col-md-5">
                  <select class="form-select border-0">
                    <option selected>Location</option>
                    <option value="1">Location 1</option>
                    <option value="1">Location 2</option>
                  </select>
                </div>
                <div className="col-md-2">
                  
                    <button class="searchCom btn btn-outline-secondary border-0 w-100">Search </button>
                  
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

<CompanyList/>


    </>
  );
}

export default Companies;
