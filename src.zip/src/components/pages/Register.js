import "./Register.css";
import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  MDBContainer,
  MDBTabs,
  MDBTabsItem,
  MDBTabsLink,
  MDBTabsContent,
  MDBTabsPane,
  MDBIcon,
  MDBInput,
  MDBCheckbox,
} from "mdb-react-ui-kit";

function Register() {
  const [justifyActive, setJustifyActive] = useState("tab1");

  const handleJustifyClick = (value) => {
    if (value === justifyActive) {
      return;
    }

    setJustifyActive(value);
  };

  return (
    <>
      <div class="container py-5 bg-dark reg-header mb-2  ">
        <div class="container my-5 pt-5 pb-4">
          <h1 class="display-3 text-white mb-3 ">Registeration Page</h1>
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb text-uppercase">
              <li class="breadcrumb-item text-white">
                <Link href="#">Home</Link>
              </li>
              <li class="breadcrumb-item text-white">
                <Link href="#">Pages</Link>
              </li>
              <li class="breadcrumb-item  active" aria-current="page">
                Registeration
              </li>
            </ol>
          </nav>
        </div>
      </div>

      <h2 className="text-center my-5 mb-1">Registeration</h2>
      <MDBContainer className="p-4  d-flex flex-column text-center w-50 auth-3d-card">
        <MDBTabs
          pills
          justify
          className="mb-3 d-flex flex-row justify-content-between  "
        >
          <MDBTabsItem>
            <MDBTabsLink
              onClick={() => handleJustifyClick("tab1")}
              active={justifyActive === "tab1"}
              className="register text-dark ">
              Login
            </MDBTabsLink>
          </MDBTabsItem>
          <MDBTabsItem >
            <MDBTabsLink
              onClick={() => handleJustifyClick("tab2")}
              active={justifyActive === "tab2"}
            className="register  text-dark">
              Register
            </MDBTabsLink>
          </MDBTabsItem>
        </MDBTabs>

        {/* User */}
        <MDBTabsContent>
          <MDBTabsPane show={justifyActive === "tab1"}>
            <div className="text-center mb-3">
              <p>Sign in with:</p>

              <div
                className="d-flex justify-content-between mx-auto"
                style={{ width: "40%" }}
              >
                <Link
                  
                  className="m-1"
                  style={{ color: "#1266f1" }}
                >
                 <i class="fa-brands fa-facebook"></i>
                </Link>

                <Link
                  
                  className="m-1"
                  style={{ color: "#1266f1" }}
                >
                  <i class="fa-brands fa-twitter"></i>
                </Link>

                <Link
                  
                  className="m-1"
                  style={{ color: "#1266f1" }}
                >
                  <i class="fa-brands fa-google"></i>
                </Link>

                <Link
                  
                  className="m-1"
                  style={{ color: "#1266f1" }}
                >
                  <i class="fa-brands fa-github"></i>
                </Link>
              </div>

              <p className="text-center mt-3">or:</p>
            </div>

            <MDBInput
              wrapperClass="mb-4"
              label="Email address"
              id="form1"
              type="email"
            />
            <MDBInput
              wrapperClass="mb-4"
              label="Password"
              id="form2"
              type="password"
            />

            <div className="d-flex justify-content-between mx-4 mb-4">
              <MDBCheckbox
                name="flexCheck"
                value=""
                id="flexCheckDefault"
                label="Remember me"
              />
              <a href="!#">Forgot password?</a>
            </div>

            <button className="regButton btn btn-outline-primary mb-4 w-100">Sign in</button>
            <p className="text-center">
              Have an account ? {" "}
              <Link
                onClick={() => handleJustifyClick("tab2")}
                active={justifyActive === "tab2"}
              >
                Register
              </Link>
            </p>
          </MDBTabsPane>


          <MDBTabsPane show={justifyActive === "tab2"}>
            <div className="text-center mb-3">
              <p>Sign un with:</p>

              <div
                className="d-flex justify-content-between mx-auto"
                style={{ width: "40%" }}
              >
                <Link
                  
                  className="m-1"
                  style={{ color: "#1266f1" }}
                >
                  <i class="fa-brands fa-facebook"></i>
                </Link>

                <Link
                  
                  className="m-1"
                  style={{ color: "#1266f1" }}
                >
                  <MDBIcon fab icon="twitter" size="sm" />
                </Link>

                <Link
                  
                  className="m-1"
                  style={{ color: "#1266f1" }}
                >
                  <i class="fa-brands fa-google"></i>
                </Link>

                <Link
                  
                  className="m-1"
                  style={{ color: "#1266f1" }}
                >
                  <i class="fa-brands fa-github"></i>
                </Link>
              </div>

              <p className="text-center mt-3">or:</p>
            </div>
            <form class="row g-3">
              <div className="row ">
                <div className="col-md-6">
                  <MDBInput
                    wrapperClass="mb-4"
                    label="Firstame"
                    id="form1"
                    type="text"
                  />
                </div>
                <div className="col-md-6">
                  <MDBInput
                    wrapperClass="mb-4"
                    label="LastName"
                    id="form1"
                    type="text"
                  />
                </div>
              </div>
              <div className="row ">
                <div className="col-md-6">
                  <MDBInput
                    wrapperClass="mb-4"
                    label="Fullname"
                    id="form1"
                    type="text"
                  />
                </div>
                <div className="col-md-6">
                  <MDBInput
                    wrapperClass="mb-4"
                    label="Username"
                    id="form1"
                    type="email"
                  />
                </div>
              </div>
              <div className="row ">
                <div className="col-md-6">
                  <select
                    class="form-select"
                    aria-label="Default select example"
                  >
                    <option selected>Open this select menu</option>
                    <option value="1">One</option>
                    <option value="2">Two</option>
                    <option value="3">Three</option>
                  </select>
                </div>
                <div className="col-md-6">
                  <MDBInput
                    wrapperClass="mb-4"
                    label="Phone Number"
                    id="form1"
                    type="text"
                  />
                </div>
              </div>
              <div className="row ">
                <div className="col-md-6">
                  <MDBInput
                    wrapperClass="mb-4"
                    label="Password"
                    id="form1"
                    type="password"
                  />
                </div>
                <div className="col-md-6 ">
                  <MDBInput
                    wrapperClass="mb-4"
                    label="ConfirmPassword"
                    id="form1"
                    type="password"
                  />
                </div>
              </div>
            </form>

            <div className="d-flex justify-content-center mb-4">
              <MDBCheckbox
                name="flexCheck"
                id="flexCheckDefault"
                label="I have read and agree to the terms"
              />
            </div>

            <button className="regButton btn btn-outline-primary mb-4 w-100">Sign up</button>
          </MDBTabsPane>
        </MDBTabsContent>


      </MDBContainer>
    </>
  );
}

export default Register;
