import React from 'react'
import { Link } from 'react-router-dom'
import './JobDetails.css'

const JobDetails = () => {
  return (
    <>
           
        <div class="container py-5 bg-dark job-header mb-2">
            <div class="container my-5 pt-5 pb-4">
                <h1 class="display-3 text-white mb-3 animated slideInDown">Job Detail</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb text-uppercase">
                        <li class="breadcrumb-item"><Link href="#">Home</Link></li>
                        <li class="breadcrumb-item"><Link href="#">Pages</Link></li>
                        <li class="breadcrumb-item text-white active" aria-current="page">Job Detail</li>
                    </ol>
                </nav>
            </div>
        </div>
    
       <div class="container-fluid py-5 wow jobDetails" data-wow-delay="0.1s">
            <div class="container">
                <div class="row gy-5 gx-4 ">
                    <div class="col-lg-8">
                        <div class="d-flex align-items-center mb-5">
                            <img class="flex-shrink-0 img-fluid border rounded" src="img/com-logo-2.jpg" alt="" style={{width: "80px", height: "80px"}}/>
                            <div class="text-start ps-4">
                                <h3 class="mb-3">Marketing Manager</h3>
                                 <span class="text-truncate me-3"><i class="fa fa-map-marker-alt text-primary me-2"></i>New York, USA</span>
                                <span class="text-truncate me-3"><i class="far fa-clock text-primary me-2"></i>Full Time</span>
                                <span class="text-truncate me-0"><i class="far fa-money-bill-alt text-primary me-2"></i>$123 - $456</span>
                            </div>
                        </div>

                        <div class="mb-5">
                            <h4 class="mb-3">Job description</h4>
                            <p>This is description.</p>
                            
                            <h4 class="mb-3">Qualifications</h4>
                            <p>This is Qualifications.</p>
                            <ul class="list-unstyled">
                                <li><i class="fa fa-angle-right text-primary me-2"></i>Dolor justo tempor duo ipsum accusam</li>
                                <li><i class="fa fa-angle-right text-primary me-2"></i>Elitr stet dolor vero clita labore gubergren</li>
                                <li><i class="fa fa-angle-right text-primary me-2"></i>Rebum vero dolores dolores elitr</li>
                                <li><i class="fa fa-angle-right text-primary me-2"></i>Est voluptua et sanctus at sanctus erat</li>
                                <li><i class="fa fa-angle-right text-primary me-2"></i>Diam diam stet erat no est est</li>
                            </ul>
                        </div>
        

                    </div>
        
                    <div class="container-card col-lg-4">
                        <div class="bg-light rounded p-5 mb-4 wow slideInUp" data-wow-delay="0.1s">
                            <h4 class="mb-4">Job Summery</h4>
                            <p><i class="fa fa-angle-right text-primary me-2"></i>Published On: 01 Jan, 2045</p>
                            <p><i class="fa fa-angle-right text-primary me-2"></i>Vacancy: 123 Position</p>
                            <p><i class="fa fa-angle-right text-primary me-2"></i>Job Nature: Full Time</p>
                            <p><i class="fa fa-angle-right text-primary me-2"></i>Salary: $123 - $456</p>
                            <p><i class="fa fa-angle-right text-primary me-2"></i>Location: New York, USA</p>
                            <p class="m-0"><i class="fa fa-angle-right text-primary me-2 mb-4"></i>Date Line: 01 Jan, 2045</p>
                            <Link class="viewJobs btn btn-outline-primary py-1" to='/register'>
                        Apply Now
                        </Link>
                        </div>
                        <div class="bg-light rounded p-5 wow slideInUp" data-wow-delay="0.1s">
                            <h4 class="mb-4">Company Detail</h4>
                            <p><i class="fa fa-angle-right text-primary me-2"></i>Name: Telenor Myanmar</p>
                            <p><i class="fa fa-angle-right text-primary me-2"></i>About: about</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </>
  )
}

export default JobDetails