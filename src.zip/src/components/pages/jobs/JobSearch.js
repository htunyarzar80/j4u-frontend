import './JobSearch.css'

const JobSearch = () => {
  return (
    <>
          <div
        className="container bg-primary mb-2 my-2 fadeIn search"
        data-delay="0.1s"
        style={{ padding: "30px" }}
      >
        <div className="container">
          <div className="row g-2">
            <div className="col-md-10">
              <div className="row g-2">
                <div className="col-md-4">
                  <input
                    type="text"
                    className="form-control border-0 h-100"
                    placeholder="Your Skill or Job Title"
                  />
                </div>
                <div className="col-md-4">
                  <select class="form-select border-0">
                    <option selected>Category</option>
                    <option value="1">Category 1</option>
                    <option value="1">Category 2</option>
                  </select>
                </div>

                <div className="col-md-4">
                  <select class="form-select border-0">
                    <option selected>Location</option>
                    <option value="1">Location 1</option>
                    <option value="1">Location 2</option>
                  </select>
                </div>
              </div>
            </div>
            <div class="col-md-2">
              <button class="searchJobs btn btn-outline-secondary border-0 w-100">Search JOB</button>
            </div>
          </div>
        </div>
      </div>
    </>
  )
}

export default JobSearch
