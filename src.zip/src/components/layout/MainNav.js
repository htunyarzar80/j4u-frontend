import { Link } from "react-router-dom";
import "./MainNav.css";
import { MDBIcon } from "mdb-react-ui-kit";
const MainNav = () => {
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light sticky-top ">
      <div className="container ">
        <Link className="navbar-brand" to="/">
          J<span className="logo">4</span>U
        </Link>
        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <MDBIcon icon="bars" fas />
        </button>
        <div className="collapse navbar-collapse " id="navbarNav">
          <ul className="navbar-nav ms-auto navUl align-items-center">
            <li className="nav-item ">
              <Link className="nav-link linkItems active " aria-current="page" to="/">
                HOME
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link linkItems" to="/jobs">
                JOBS
              </Link>
            </li>

            <li className="nav-item">
              <Link className="nav-link linkItems" to="/companies">
                COMPANIES
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link linkItems" to="/about">
                ABOUT US
              </Link>
            </li>


            <li className="nav-item ms-3">
            <div class="dropdown">
        <Link
          class="dropdown-toggle d-flex align-items-center hidden-arrow"
          href="#"
          id="navbarDropdownMenuAvatar"
          role="button"
          data-mdb-toggle="dropdown"
          aria-expanded="false"
        >
         <i class="fas fa-user  "></i>
        </Link>
        <ul
          class="dropdown-menu dropdown-menu-end"
          aria-labelledby="navbarDropdownMenuAvatar"
        >
          <li>
            <Link class="dropdown-item" to="/profile">My profile</Link>
          </li>
          <li>
            <Link class="dropdown-item" href="#">Settings</Link>
          </li>
          <li>
            <Link class="dropdown-item" href="#">Logout</Link>
          </li>
        </ul>
      </div>
        </li>
            <div className="ms-4 mx-3">
              <Link to="/register">
                <button className="button btn btn-outline-primary ">LOGIN</button>
              </Link>
            </div>
            {/* <div className="form-check form-switch ms-auto">
              <input
                className="form-check-input"
                type="checkbox"
                id="flexSwitchCheckDefault"
              />
              <label className="form-check-label" for="flexSwitchCheckDefault">
                Dark Mode
              </label>
            </div> */}
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default MainNav;
