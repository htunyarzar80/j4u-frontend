import React from "react";
import "./JobTable.css";
import { Link } from "react-router-dom";


function JobTable() {
  return (
    <>
    <div className="container my-5 offset-md-2">
      <div className="col-md-10 ">
        <div className="container my-3">
          <div className="row">
            <div className="col-md-10">
              <h2>JobTable</h2>
            </div>
            <div className="col-md-2">
              <Link class="btn p-2 btn-outline-primary btn-rounded" to="/jobform">
                Create Job
              </Link>
            </div>
          </div>
        </div>
        <div class="container-fluid table-responsive w-100">
          <table class="table table-hover table-sm">
            <thead>
              <tr>
                <th scope="col">id</th>
                <th scope="col">Title</th>
                <th scope="col">Type</th>
                <th scope="col">Category</th>
                <th scope="col">Status</th>
                <th scope="col">Location</th>
                <th scope="col">Company</th>
                <th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1,001</td>
                <td>random</td>
                <td>data</td>
                <td>placeholder</td>
                <td>placeholder</td>
                <td>data</td>
                <td>placeholder</td>
                <td>
                  <Link class="btn-outline-primary">Details</Link>
                </td>
              </tr>
              <tr>
                <td>1,001</td>
                <td>random</td>
                <td>data</td>
                <td>placeholder</td>
                <td>placeholder</td>
                <td>data</td>
                <td>placeholder</td>
                <td>
                  <Link class="btn-outline-primary">Details</Link>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    </>
  );
}

export default JobTable;
